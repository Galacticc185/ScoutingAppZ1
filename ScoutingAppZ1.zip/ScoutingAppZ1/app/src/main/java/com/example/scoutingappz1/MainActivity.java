package com.example.scoutingappz1;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Bundle;
import java.util.Date;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.graphics.Typeface;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Build;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    static String scouterName;
    static String teamNumber;
    static String matchNumber;
    static int elap = 0;
    static inputText time;
    static Runnable runnable;
    static boolean teleop = false;
    static int flasher;
    static int algaeFloor;
    static int netShot;
    static int deepBarge = 0;
    static int shallowBarge = 0;
    static int FcoralL1;
    static int FcoralL2;
    static int FcoralL3;
    static int FcoralL4;
    static int BcoralL1;
    static int BcoralL2;
    static int BcoralL3;
    static int BcoralL4;
    static int source;
    static int processor;
    static int algaeRemoved;
















    static int AalgaeRemoved;
















    static int AalgaeFloor;
    static int AnetShot;
    static int AFcoralL1;
    static int AFcoralL2;
    static int AFcoralL3;
    static int AFcoralL4;
    static int ABcoralL1;
    static int ABcoralL2;
    static int ABcoralL3;
    static int ABcoralL4;
    static int Aprocessor;
    static int netMiss;
    static int processorMiss;
    static boolean inMenu = false;
















































    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout layout = new FrameLayout(this);
        layout.setBackgroundColor(Color.BLACK);
        getSupportActionBar().hide();
















        But playButton = new But(312, 100, 400, 100, Color.BLACK, this, layout);
        TextView pText = new TextView(this);
        pText.setTypeface(Typeface.MONOSPACE);
        pText.setElevation(100);
        pText.setText("START");
        pText.setTextColor(Color.WHITE);
        pText.setX(390);
        pText.setY(94);
        pText.setTextSize(80);
        TextView cText = new TextView(this);
        cText.setText("Change Info");
        cText.setTypeface(Typeface.MONOSPACE);
        cText.setElevation(100);
        cText.setTextColor(Color.WHITE);
        cText.setX(329);
        cText.setY(310);
        cText.setTextSize(55);
        layout.addView(pText);
        layout.addView(cText);
        But changeInfo = new But(312, 300, 400, 100, Color.BLACK, this, layout);
        playButton.setOnClickEvent(e -> {
            System.out.println(scouterName + teamNumber + matchNumber);
            layout.removeAllViews();
            But backButtonPlay = new But(0, 0, 2000, 2000, Color.rgb(171, 27, 17), this, layout);
            backButtonPlay.setOnClickEvent(en -> {
                layout.setBackgroundColor(Color.BLACK);
                layout.removeAllViews();
                layout.addView(playButton.myButton);
                layout.addView(changeInfo.myButton);
                layout.addView(pText);
                layout.addView(cText);
            });
            But StartGame = new But(250, 0, 2000, 2000, Color.rgb(46, 143, 39), this, layout);
            StartGame.setOnClickEvent(en -> {
                layout.setBackgroundColor(Color.BLACK);
                layout.removeAllViews();
                ImageView field = new ImageView(this);
                field.setImageResource(R.drawable.field);
                layout.addView(field);
                // add buttons here
                But Floor = new But(70,57,880,400,Color.TRANSPARENT, this, layout);
//                Floor.myButton.setBackgroundColor(Color.TRANSPARENT);
                Floor.myButton.setTranslationZ(-1000000);
                Floor.flash(Color.BLACK, "algaeFloor", -100000);
                ButCir Algae1 = new ButCir( 190,247,20,Color.GREEN,this, layout);
                Algae1.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae1.remove(layout);
                });
                ButCir Algae2 = new ButCir( 240,335,20,Color.GREEN,this, layout);
                Algae2.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae2.remove(layout);
                });
                ButCir Algae3 = new ButCir( 240,160,20,Color.GREEN,this, layout);
                Algae3.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae3.remove(layout);
                });
                ButCir Algae4 = new ButCir( 390,247,20,Color.GREEN,this, layout);
                Algae4.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae4.remove(layout);
                });
                ButCir Algae5 = new ButCir( 340,335,20,Color.GREEN,this, layout);
                Algae5.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae5.remove(layout);
                });
                ButCir Algae6 = new ButCir( 340,160,20,Color.GREEN,this, layout);
                Algae6.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae6.remove(layout);
                });
                ButCir Algae7 = new ButCir( 800,247,20,Color.GREEN,this, layout);
                Algae7.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae7.remove(layout);
                });
                ButCir Algae8 = new ButCir( 750,335,20,Color.GREEN,this, layout);
                Algae8.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae8.remove(layout);
                });
                ButCir Algae9 = new ButCir( 750,160,20,Color.GREEN,this, layout);
                Algae9.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae9.remove(layout);
                });
                ButCir Algae10 = new ButCir( 600,247,20,Color.GREEN,this, layout);
                Algae10.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae10.remove(layout);
                });
                ButCir Algae11 = new ButCir( 650,335,20,Color.GREEN,this, layout);
                Algae11.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae11.remove(layout);
                });
                ButCir Algae12 = new ButCir( 650,160,20,Color.GREEN,this, layout);
                Algae12.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae12.remove(layout);
                });
                ButCir Algae13 = new ButCir( 110,247,20,Color.GREEN,this, layout);
                Algae13.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae13.remove(layout);
                });
                ButCir Algae14 = new ButCir( 110,335,20,Color.GREEN,this, layout);
                Algae14.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae14.remove(layout);
                });
                ButCir Algae15 = new ButCir( 110,160,20,Color.GREEN,this, layout);
                Algae15.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae15.remove(layout);
                });
                ButCir Algae16 = new ButCir( 880,247,20,Color.GREEN,this, layout);
                Algae16.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae16.remove(layout);
                });
                ButCir Algae17 = new ButCir( 880,335,20,Color.GREEN,this, layout);
                Algae17.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae17.remove(layout);
                });
                ButCir Algae18 = new ButCir( 880,160,20,Color.GREEN,this, layout);
                Algae18.setOnClickEvent(a1 -> {
                    if(MainActivity.teleop)
                        algaeRemoved++;
                    if(!MainActivity.teleop)
                        AalgaeRemoved++;
                    Algae18.remove(layout);
                });
                But BlueNet = new But(484,67,55,195,Color.TRANSPARENT, this, layout);
                BlueNet.flash(Color.BLACK, "netShot", 100);
                But RedNet = new But(484,265,55,195,Color.TRANSPARENT, this, layout);
                RedNet.flash(Color.BLACK, "netShot", 100);
                But NetMiss = new But(200,5,90,45,Color.DKGRAY, this, layout);
                NetMiss.flash(Color.BLACK, "netMiss", 100);
                NetMiss.setText(" Net Miss",20);
                NetMiss.tp.setElevation(10000);
                But ProcessorMiss = new But(300,5,147,45,Color.DKGRAY, this, layout);
                ProcessorMiss.flash(Color.BLACK, "processorMiss", 100);
                ProcessorMiss.setText(" Processor Miss",20);
                ProcessorMiss.tp.setElevation(10000);
                //buttons menu
                But L1 = new But(150,370,75,75,Color.rgb(116, 134, 173), this, layout);
                L1.myButton.setElevation(200);
                L1.myButton.setStateListAnimator(null);
                L1.setText("L1", 40);
                L1.remove(layout);
                But L2 = new But(300,370,75,75,Color.rgb(116, 134, 173), this, layout);
                L2.myButton.setElevation(200);
                L2.myButton.setStateListAnimator(null);
                L2.setText("L2", 40);
                L2.remove(layout);
                But L3 = new But(450,370,75,75,Color.rgb(116, 134, 173), this, layout);
                L3.myButton.setElevation(200);
                L3.myButton.setStateListAnimator(null);
                L3.setText("L3", 40);
                L3.remove(layout);
                But L4 = new But(600,370,75,75,Color.rgb(116, 134, 173), this, layout);
                L4.myButton.setElevation(200);
                L4.myButton.setStateListAnimator(null);
                L4.setText("L4", 40);
                L4.remove(layout);
                But PLAYBACK = new But(750,370,75,75,Color.RED, this, layout);
                PLAYBACK.remove(layout);
                PLAYBACK.myButton.setElevation(200);
                PLAYBACK.myButton.setStateListAnimator(null);
                Rectangle BG = new Rectangle(0,320,1000,300,this, layout);
                BG.rectangleView.setElevation(190);
                BG.setOpacity(.8F);
                BG.remove(layout);
                But CoralBlueFront = new But(251,217,55,100,Color.YELLOW, this, layout);
                CoralBlueFront.setColor(Color.TRANSPARENT);
                CoralBlueFront.myButton.setOnClickListener(a -> {
















                    if (!inMenu) {
                        inMenu = true;
                        CoralBlueFront.setColor(Color.BLUE);
                        BG.add(layout);
                        L1.add(layout);
                        L2.add(layout);
                        L3.add(layout);
                        L4.add(layout);
                        L1.myButton.setElevation(200);
                        L2.myButton.setElevation(200);
                        L3.myButton.setElevation(200);
                        L4.myButton.setElevation(200);
                        PLAYBACK.myButton.setElevation(200);
                        BG.rectangleView.setElevation(190);
                        PLAYBACK.add(layout);
                        PLAYBACK.myButton.setOnClickListener(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                        });
                        L1.setOnClickEvent(b -> {
//                            L1.myButton.setElevation(-20000);
                            L1.remove(layout);
//                            L1.setColor(Color.RED);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL1++;
                            else
                                AFcoralL1++;
                        });
                        L2.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL2++;
                            else
                                AFcoralL2++;
                        });
                        L3.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL3++;
                            else
                                AFcoralL3++;
                        });
                        L4.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL4++;
                            else
                                AFcoralL4++;
                        });
                    }
                });
                But CoralBlueBack = new But(313,217,55,100,Color.DKGRAY, this, layout);
                CoralBlueBack.setColor(Color.TRANSPARENT);
                CoralBlueBack.myButton.setOnClickListener(a -> {
















                    if (!inMenu) {
                        inMenu = true;
                        CoralBlueBack.setColor(Color.BLUE);
                        BG.add(layout);
                        L1.add(layout);
                        L2.add(layout);
                        L3.add(layout);
                        L4.add(layout);
                        L1.myButton.setElevation(200);
                        L2.myButton.setElevation(200);
                        L3.myButton.setElevation(200);
                        L4.myButton.setElevation(200);
                        PLAYBACK.myButton.setElevation(200);
                        BG.rectangleView.setElevation(190);
                        PLAYBACK.add(layout);
                        PLAYBACK.myButton.setOnClickListener(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                        });
                        L1.setOnClickEvent(b -> {
//                            L1.myButton.setElevation(-20000);
                            L1.remove(layout);
//                            L1.setColor(Color.RED);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL1++;
                            else
                                ABcoralL1++;
                        });
                        L2.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL2++;
                            else
                                ABcoralL2++;
                        });
                        L3.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL3++;
                            else
                                ABcoralL3++;
                        });
                        L4.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralBlueBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL4++;
                            else
                                ABcoralL4++;
                        });
                    }
                });
                But CoralRedBack = new But(657,217,55,100,Color.DKGRAY, this, layout);
                CoralRedBack.setColor(Color.TRANSPARENT);
                CoralRedBack.myButton.setOnClickListener(a -> {
















                    if (!inMenu) {
                        inMenu = true;
                        CoralRedBack.setColor(Color.BLUE);
                        BG.add(layout);
                        L1.add(layout);
                        L2.add(layout);
                        L3.add(layout);
                        L4.add(layout);
                        L1.myButton.setElevation(200);
                        L2.myButton.setElevation(200);
                        L3.myButton.setElevation(200);
                        L4.myButton.setElevation(200);
                        PLAYBACK.myButton.setElevation(200);
                        BG.rectangleView.setElevation(190);
                        PLAYBACK.add(layout);
                        PLAYBACK.myButton.setOnClickListener(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                        });
                        L1.setOnClickEvent(b -> {
//                            L1.myButton.setElevation(-20000);
                            L1.remove(layout);
//                            L1.setColor(Color.RED);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL1++;
                            else
                                ABcoralL1++;
                        });
                        L2.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL2++;
                            else
                                ABcoralL2++;
                        });
                        L3.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL3++;
                            else
                                ABcoralL3++;
                        });
                        L4.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedBack.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                BcoralL4++;
                            else
                                ABcoralL4++;
                        });
                    }
                });
                But CoralRedFront = new But(719,217,55,100,Color.YELLOW, this, layout);
                CoralRedFront.setColor(Color.TRANSPARENT);
                CoralRedFront.myButton.setOnClickListener(a -> {
















                    if (!inMenu) {
                        inMenu = true;
                        CoralRedFront.setColor(Color.BLUE);
                        BG.add(layout);
                        L1.add(layout);
                        L2.add(layout);
                        L3.add(layout);
                        L4.add(layout);
                        L1.myButton.setElevation(200);
                        L2.myButton.setElevation(200);
                        L3.myButton.setElevation(200);
                        L4.myButton.setElevation(200);
                        PLAYBACK.myButton.setElevation(200);
                        BG.rectangleView.setElevation(190);
                        PLAYBACK.add(layout);
                        PLAYBACK.myButton.setOnClickListener(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                        });
                        L1.setOnClickEvent(b -> {
//                            L1.myButton.setElevation(-20000);
                            L1.remove(layout);
//                            L1.setColor(Color.RED);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL1++;
                            else
                                AFcoralL1++;
                        });
                        L2.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL2++;
                            else
                                AFcoralL2++;
                        });
                        L3.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL3++;
                            else
                                AFcoralL3++;
                        });
                        L4.setOnClickEvent(b -> {
                            L1.remove(layout);
                            L2.remove(layout);
                            L3.remove(layout);
                            L4.remove(layout);
                            BG.remove(layout);
                            PLAYBACK.remove(layout);
                            CoralRedFront.setColor(Color.TRANSPARENT);
                            inMenu = false;
                            if(MainActivity.teleop)
                                FcoralL4++;
                            else
                                AFcoralL4++;
                        });
                    }
                });
                CoralRedFront.myButton.setTranslationZ(-10000);
                But BlueDeepBarge = new But(440,113,40,40,Color.rgb(18, 35, 64), this, layout);
                BlueDeepBarge.flashWithTimer(Color.WHITE, "deepBarge", 10000);
                But BlueShallowBarge = new But(440,163,40,40,Color.rgb(93, 137, 212), this, layout);
                BlueShallowBarge.flashWithTimer(Color.WHITE, "shallowBarge", 1000);
                But RedDeepBarge = new But(543,374,40,40,Color.rgb(18, 35, 64), this, layout);
                RedDeepBarge.flashWithTimer(Color.WHITE, "deepBarge", 10000);
                But RedShallowBarge = new But(543,324,40,40,Color.rgb(93, 137, 212), this, layout);
                RedShallowBarge.flashWithTimer(Color.WHITE, "shallowBarge", 10000);
                But BlueSourceTop = new But(94,28,45,120,Color.TRANSPARENT, this, layout);
                BlueSourceTop.setRotation(53);
                BlueSourceTop.flash(Color.BLACK, "source", 100);
                But BlueSourceBottom = new But(94,386,45,120,Color.TRANSPARENT, this, layout);
                BlueSourceBottom.setRotation(127);
                BlueSourceBottom.flash(Color.BLACK, "source", 100);
                But RedSourceTop = new But(889,28,45,120,Color.TRANSPARENT, this, layout);
                RedSourceTop.setRotation(127);
                RedSourceTop.flash(Color.BLACK, "source", 100);
                But RedSourceBottom = new But(889,386,45,120,Color.TRANSPARENT, this, layout);
                RedSourceBottom.setRotation(53);
                RedSourceBottom.flash(Color.BLACK, "source", 100);
                But BlueProcessor = new But(330,445,120,50,Color.TRANSPARENT, this, layout);
                BlueProcessor.flash(Color.BLACK, "processor", 100);
                But RedProcessor = new But(560,25,125,50,Color.TRANSPARENT, this, layout);
                RedProcessor.flash(Color.BLACK, "processor", 100);
                But finishData = new But(950, 450, 50, 50, Color.WHITE, this, layout);
                finishData.setOnClickEvent(eer -> {
                    System.out.println(elap);
                    if (elap == 16) {
                        teleop = true;
                        int interval = 1000;
                        Handler handler = new Handler();
                        runnable = new Runnable() {
                            @Override
                            public void run() {
                                // Your repeated task here
                                time.textBar.setText(Integer.toString(elap));
                                elap += 1;
                                if (elap == 11) {
                                    time.textBar.setX(950);
                                }
//                            System.out.println(teleop);
                                if (elap == 150) {
                                    handler.removeCallbacks(this);
                                    writeCsvFile(MainActivity.this);
                                    saveCsvFile(MainActivity.this);
                                } else {
                                    handler.postDelayed(this, interval);
                                }
                                // Re-run the task after the interval
                            }
                        };
                        handler.post(runnable);
                    }
                });
                elap = 0;
                time = new inputText(20,480, 230, 100, 100, Color.BLUE, Integer.toString(elap), layout, this);
                time.textBar.setElevation(10000000);
                Handler handler = new Handler();
                int interval = 1000; // Interval in milliseconds (e.g., 1000ms = 1 second)
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        // Your repeated task here
                        time.textBar.setText(Integer.toString(elap));
                        elap += 1;
                        if (elap == 11) {
                            time.textBar.setX(950);
                        }
//                        System.out.println(teleop);
                        if (elap > 15) {
//                            MainActivity.teleop = true;
                            handler.removeCallbacks(this);
                        }
                        else {
                            handler.postDelayed(this, interval);
                        }
































                    }
                };
                handler.post(runnable);
            });
        });
        changeInfo.setOnClickEvent(e -> {
            layout.removeAllViews();
            inputText SNT = new inputText(50, 180, 36, 400,200, Color.WHITE, "Scouter Name",layout, this);
            inputText TNT = new inputText(50, 180, 115, 400,200, Color.WHITE, "Team Number",layout, this);
            inputText DNT = new inputText(50, 180, 194, 400,200, Color.WHITE, "Match Number",layout, this);
            But backButton = new But(50, 50, 50, 50, Color.rgb(171, 27, 17), this, layout);
            backButton.setOnClickEvent(ev -> {
                layout.removeAllViews();
                layout.addView(playButton.myButton);
                layout.addView(changeInfo.myButton);
                layout.addView(pText);
                layout.addView(cText);
            });
        });
        // end of button adding area
        setContentView(layout);
































































































































    }
    public void writeCsvFile(Context context) {
        // Scoped Storage (Android 10 and above)
        // Access the existing "data.csv" file in the Downloads folder using MediaStore
        File downloadsDirectory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "data.csv");
        try (FileWriter writer = new FileWriter(downloadsDirectory, true)) {
            // Append data to the existing file
            writer.append("Team Number, Match Number, Scouter Name, Auton Front Coral L1, Auton Front Coral L2, Auton Front Coral L3, Auton Front Coral L4, Auton Back Coral L1, Auton Front Coral L2, Auton Front Coral L3, Auton Front Coral L4, Auton Algae Removed, Auton Net Shots, Auton Processor, Coral L1F, Coral L1B, Coral L2F, Coral L2B, Coral L3F, Coral L3B, Coral L4F, Coral L4B, Algae Removed, Algae Net, Algae Net Miss, Processor, Processor Miss, Coral Station Intake, Algae Intake, Deep Climb, Shallow Climb\n");
            writer.append(MainActivity.teamNumber + ", " + MainActivity.matchNumber + ", " + MainActivity.scouterName  + ", " + MainActivity.AFcoralL1 + ", " + MainActivity.AFcoralL2  + ", " + MainActivity.AFcoralL3  + ", " + MainActivity.AFcoralL4  + ", " + MainActivity.ABcoralL1  + ", " + MainActivity.ABcoralL2 + ", " + MainActivity.ABcoralL3  + ", " + MainActivity.ABcoralL4  + ", " + MainActivity.AalgaeRemoved  + ", " + MainActivity.AnetShot  + ", " + MainActivity.Aprocessor + ", " + MainActivity.FcoralL1  + ", " + MainActivity.BcoralL1 + ", " + MainActivity.FcoralL2 + ", " + MainActivity.BcoralL2 + ", " + MainActivity.FcoralL3 + ", " + MainActivity.BcoralL3 + ", " + MainActivity.FcoralL4 + ", " + MainActivity.BcoralL4 + ", " + MainActivity.algaeRemoved  + ", " + MainActivity.netShot + ", " + MainActivity.netMiss + ", " + MainActivity.processor + ", " + MainActivity.processorMiss + ", " + MainActivity.source + ", " + MainActivity.algaeFloor  + ", " + MainActivity.deepBarge  + ", " + MainActivity.shallowBarge+"\n");
            writer.flush();
            Log.d("CSV", "File written successfully to: " + downloadsDirectory.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("CSV", "Error writing file: " + e.getMessage());
        }
    }
    public void saveCsvFile(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // For Android 10 (API 29) and above, use MediaStore to write files
            ContentValues values = new ContentValues();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String timeOfCreation = sdf.format(new Date());
            values.put(MediaStore.Downloads.DISPLAY_NAME, "data_" + timeOfCreation + "_" + scouterName + "_.csv");  // File name
            values.put(MediaStore.Downloads.MIME_TYPE, "text/csv");      // MIME type
            values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/");  // Downloads folder
            // Insert the content values into the MediaStore
            Uri uri = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            }
            try (OutputStream outputStream = context.getContentResolver().openOutputStream(uri)) {
                if (outputStream != null) {
                    // Write to the file
                    OutputStreamWriter writer = new OutputStreamWriter(outputStream);
                    writer.write("Team Number, Match Number, Scouter Name, Auton Front Coral L1, Auton Front Coral L2, Auton Front Coral L3, Auton Front Coral L4, Auton Back Coral L1, Auton Back Coral L2, Auton Back Coral L3, Auton Back Coral L4, Auton Algae Removed, Auton Net Shots, Auton Processor, Coral L1F, Coral L1B, Coral L2F, Coral L2B, Coral L3F, Coral L3B, Coral L4F, Coral L4B, Algae Removed, Algae Net, Algae Net Miss, Processor, Processor Miss, Coral Station Intake, Algae Intake, Deep Climb, Shallow Climb\n");
                    writer.write(MainActivity.teamNumber + ", " + MainActivity.matchNumber + ", " + MainActivity.scouterName  + ", " + MainActivity.AFcoralL1 + ", " + MainActivity.AFcoralL2  + ", " + MainActivity.AFcoralL3  + ", " + MainActivity.AFcoralL4  + ", " + MainActivity.ABcoralL1  + ", " + MainActivity.ABcoralL2 + ", " + MainActivity.ABcoralL3  + ", " + MainActivity.ABcoralL4  + ", " + MainActivity.AalgaeRemoved  + ", " + MainActivity.AnetShot  + ", " + MainActivity.Aprocessor  + ", " + MainActivity.FcoralL1  + ", " + MainActivity.BcoralL1 + ", " + MainActivity.FcoralL2 + ", " + MainActivity.BcoralL2 + ", " + MainActivity.FcoralL3 + ", " + MainActivity.BcoralL3 + ", " + MainActivity.FcoralL4 + ", " + MainActivity.BcoralL4 + ", " + MainActivity.algaeRemoved  + ", " + MainActivity.netShot + ", " + MainActivity.netMiss + ", " + MainActivity.processor + ", " + MainActivity.processorMiss + ", " + MainActivity.source + ", " + MainActivity.algaeFloor  + ", " + MainActivity.deepBarge  + ", " + MainActivity.shallowBarge +"\n");
                    writer.flush();
                    writer.close();
                    System.out.println("Team Number, Match Number, Scouter Name, Auton Front Coral L1, Auton Front Coral L2, Auton Front Coral L3, Auton Front Coral L4, Auton Back Coral L1, Auton Back Coral L2, Auton Back Coral L3, Auton Back Coral L4, Auton Algae Removed, Auton Net Shots, Auton Processor, Coral L1F, Coral L1B, Coral L2F, Coral L2B, Coral L3F, Coral L3B, Coral L4F, Coral L4B, Algae Removed, Algae Net, Algae Net Miss, Processor, Processor Miss, Coral Station Intake, Algae Intake, Deep Climb, Shallow Climb\n");
                    System.out.println(MainActivity.teamNumber + ", " + MainActivity.matchNumber + ", " + MainActivity.scouterName  + ", " + MainActivity.AFcoralL1 + ", " + MainActivity.AFcoralL2  + ", " + MainActivity.AFcoralL3  + ", " + MainActivity.AFcoralL4  + ", " + MainActivity.ABcoralL1  + ", " + MainActivity.ABcoralL2 + ", " + MainActivity.ABcoralL3  + ", " + MainActivity.ABcoralL4  + ", " + MainActivity.AalgaeRemoved  + ", " + MainActivity.AnetShot  + ", " + MainActivity.Aprocessor  + ", " + MainActivity.FcoralL1  + ", " + MainActivity.BcoralL1 + ", " + MainActivity.FcoralL2 + ", " + MainActivity.BcoralL2 + ", " + MainActivity.FcoralL3 + ", " + MainActivity.BcoralL3 + ", " + MainActivity.FcoralL4 + ", " + MainActivity.BcoralL4 + ", " + MainActivity.algaeRemoved  + ", " + MainActivity.netShot + ", " + MainActivity.netMiss + ", " + MainActivity.processor + ", " + MainActivity.processorMiss + ", " + MainActivity.source + ", " + MainActivity.algaeFloor  + ", " + MainActivity.deepBarge  + ", " + MainActivity.shallowBarge +"\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // For older versions, you can use the older methods (like External Storage)
            System.out.println("somethings fucked up");
        }
    }
}
class But {
    float xPos;
    float yPos;
    float width;
    float height;
    String shape;
    int color;
    int flasher;
    Button myButton;
    Context tt;
    FrameLayout ll;
    TextView tp;
    public But(float xp, float yp, float w, float h, int c, Context t, FrameLayout l) {
        tt = t;
        ll = l;
        xPos = xp;
        yPos = yp;
        width = w;
        color = c;
        height = h;
        myButton = new Button(t);
        myButton.setX(xPos);
        myButton.setY(yPos);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                (int) w,  // Width in pixels
                (int) h   // Height in pixels
        );
        myButton.setLayoutParams(params);
        myButton.setBackgroundColor(c);
        l.addView(myButton);
    }
    public void setOnClickEvent(View.OnClickListener listener) {
        myButton.setOnClickListener(listener);
    }
    public void setColor(int c) {
        myButton.setBackgroundColor(c);
        color = c;
    }
    public void remove(FrameLayout layout) {
        layout.removeView(myButton);
        if (tp != null) {
            layout.removeView(tp);
        }
















    }
    public void add(FrameLayout layout) {
        layout.addView(myButton);
        if (tp != null) {
            layout.addView(tp);
        }
    }
    public void setRotation(float angle) {
        // Rotate the button by the specified angle (in degrees)
        myButton.setRotation(angle);
    }
    public void setElevation(int l) {
        myButton.setElevation(l);
    }
    public void setZ(float zIndex) {
        myButton.setZ(zIndex);
    }
    public void setText(String txt, int ss) {
        tp = new TextView(tt);
        tp.setText(txt);
        tp.setTextSize(ss);
        tp.setX(xPos);
        tp.setY(yPos);
        tp.setElevation(myButton.getElevation() + 10);
        ll.addView(tp);
    }
    public void flash(int col, String dataType, int el) {








        this.setOnClickEvent(n -> {
            this.myButton.setZ(el);
            this.myButton.setBackgroundColor(col);
            this.myButton.setTranslationZ(el);
            if(MainActivity.teleop) {
                if (dataType.equals("algaeFloor"))
                    MainActivity.algaeFloor++;
                if (dataType.equals("netShot"))
                    MainActivity.netShot++;








                if (dataType.equals("netMiss"))
                    MainActivity.netMiss++;
                if (dataType.equals("processorMiss"))
                    MainActivity.processorMiss++;








                if (dataType.equals("FL1"))
                    MainActivity.FcoralL1++;
                if (dataType.equals("FL2"))
                    MainActivity.FcoralL2++;
                if (dataType.equals("FL3"))
                    MainActivity.FcoralL3++;
                if (dataType.equals("FL4"))
                    MainActivity.FcoralL4++;








                if (dataType.equals("BL1"))
                    MainActivity.BcoralL1++;
                if (dataType.equals("BL2"))
                    MainActivity.BcoralL2++;
                if (dataType.equals("BL3"))
                    MainActivity.BcoralL3++;
                if (dataType.equals("BL4"))
                    MainActivity.BcoralL4++;








                if (dataType.equals("deepBarge"))
                    MainActivity.deepBarge++;
                if (dataType.equals("shallowBarge"))
                    MainActivity.shallowBarge++;








                if (dataType.equals("source"))
                    MainActivity.source++;
                if (dataType.equals("processor"))
                    MainActivity.processor++;
            }else{
                if (dataType.equals("algaeFloor"))
                    MainActivity.AalgaeFloor++;
                if (dataType.equals("netShot"))
                    MainActivity.AnetShot++;








                if (dataType.equals("FL1"))
                    MainActivity.AFcoralL1++;
                if (dataType.equals("FL2"))
                    MainActivity.AFcoralL2++;
                if (dataType.equals("FL3"))
                    MainActivity.AFcoralL3++;
                if (dataType.equals("FL4"))
                    MainActivity.AFcoralL4++;








                if (dataType.equals("BL1"))
                    MainActivity.ABcoralL1++;
                if (dataType.equals("BL2"))
                    MainActivity.ABcoralL2++;
                if (dataType.equals("BL3"))
                    MainActivity.ABcoralL3++;
                if (dataType.equals("BL4"))
                    MainActivity.ABcoralL4++;








                if (dataType.equals("processor"))
                    MainActivity.Aprocessor++;
            }
















            flasher = 0;
            int interval = 150;
            Handler handler = new Handler();
            Runnable runnable2 = new Runnable() {
                @Override
                public void run() {
                    flasher++;
                    if (flasher == 2) {
                        flasher = 0;
                        handler.removeCallbacks(this);
                        myButton.setBackgroundColor(color);
                        myButton.setTranslationZ(el);
                    } else {
//                        myButton.setBackgroundColor(col);
                        handler.postDelayed(this, interval);
                    }
































                }
            };
            handler.post(runnable2);
        });
    }
    // Inside your But class








    // Static variables to store final values for climb times








    // Timer variables
    private long shallowStartTime = 0; // Start time for shallow climb
    private long deepStartTime = 0; // Start time for deep climb








    // Method to handle climb timing and store the result in the respective variable
    private void handleClimbTimer(String climbType) {
        if (climbType.equals("shallowBarge")) {
            if (shallowStartTime == 0) {
                // Start the shallow climb timer
                shallowStartTime = System.currentTimeMillis();
                Log.d("ClimbTimer", "Shallow climb timer started");
            } else {
                // Stop the shallow climb timer and calculate elapsed time
                long elapsedTime = System.currentTimeMillis() - shallowStartTime;
                shallowStartTime = 0; // Reset for the next shallow climb
                MainActivity.shallowBarge += (int) elapsedTime; // Store elapsed time as total
                Log.d("ClimbTimer", "Shallow climb elapsed time: " + elapsedTime + " ms");
                System.out.println(MainActivity.shallowBarge);
            }
        } else if (climbType.equals("deepBarge")) {
            if (deepStartTime == 0) {
                // Start the deep climb timer
                deepStartTime = System.currentTimeMillis();
                Log.d("ClimbTimer", "Deep climb timer started");
            } else {
                // Stop the deep climb timer and calculate elapsed time
                long elapsedTime = System.currentTimeMillis() - deepStartTime;
                deepStartTime = 0; // Reset for the next deep climb
                MainActivity.deepBarge += (int) elapsedTime; // Store elapsed time as total
                Log.d("ClimbTimer", "Deep climb elapsed time: " + elapsedTime + " ms");
                System.out.println(MainActivity.deepBarge);
            }
        }
    }








    // Method to combine flashing and climb timing
    public void flashWithTimer(int col, String climbType, int el) {
        this.setOnClickEvent(n -> {
            // Handle the climb timer logic
            handleClimbTimer(climbType);








            // Perform flashing logic
            myButton.setZ(el);
            myButton.setBackgroundColor(col);
            myButton.setTranslationZ(el);








            // Flashing effect logic
            flasher = 0;
            int interval = 150; // Flash interval in milliseconds
            Handler handler = new Handler();
            Runnable runnable2 = new Runnable() {
                @Override
                public void run() {
                    flasher++;
                    if (flasher == 2) {
                        flasher = 0;
                        handler.removeCallbacks(this);
                        myButton.setBackgroundColor(color);
                        myButton.setTranslationZ(el);
                    } else {
                        handler.postDelayed(this, interval);
                    }
                }
            };
            handler.post(runnable2);
        });
    }
































}
































































class ButCir {
    private float xPos;
    private float yPos;
    private float radius;
    public Button myButton;
    GradientDrawable background;
    public ButCir(float xp, float yp, float r, int color, Context context, FrameLayout layout) {
        xPos = xp;
        yPos = yp;
        radius = r;
        myButton = new Button(context);
        myButton.setX(xPos);
        myButton.setY(yPos);
        // Set layout parameters for the button
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                (int) (2 * radius),  // Width = diameter
                (int) (2 * radius)   // Height = diameter
        );
        myButton.setLayoutParams(params);
        // Create a circular background
        background = new GradientDrawable();
        background.setShape(GradientDrawable.OVAL); // Makes the background circular
        background.setColor(color); // Sets the background color
        myButton.setBackground(background);
        layout.addView(myButton);
    }
    public void setOnClickEvent(View.OnClickListener listener) {
        myButton.setOnClickListener(listener);
    }
    public void setColor(int color) {
        // Update the button's background color dynamically
        GradientDrawable background = (GradientDrawable) myButton.getBackground();
        background.setColor(color);
    }
    public void remove(FrameLayout layout){
        layout.removeView(myButton);
    }
}
class Rectangle {
    public View rectangleView;
















    public Rectangle(float xPos, float yPos, float width, float height, Context context, FrameLayout layout) {
        // Create the rectangle view
        rectangleView = new View(context); //fuck younah ur short gay faggy twig
















        // Set position, size, and background color
        rectangleView.setX(xPos);
        rectangleView.setY(yPos);
        rectangleView.setBackgroundColor(Color.BLACK); // Black rectangle
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams((int) width, (int) height);
        rectangleView.setLayoutParams(params);
















        // Add the rectangle to the layout
        layout.addView(rectangleView);
    }
















    // Remove the rectangle from the layout
    public void remove(FrameLayout layout) {
        layout.removeView(rectangleView);
    }
    public void setZ(float zIndex) {
        rectangleView.setZ(zIndex);
    }
    public void add(FrameLayout layout) {
        layout.addView(rectangleView);
    }
    public void setOpacity(float alpha) {
        rectangleView.setAlpha(alpha); // Alpha value: 0.0f to 1.0f
    }
}
class Texter{
    private TextView text;
    public Texter(int col, String t, int xPos, int yPos, int size, Typeface font, Context c, FrameLayout fl){
        text = new TextView(c);
        text.setText(t);
        text.setTextColor(col);
        text.setX(xPos);
        text.setY(yPos);
        text.setTextSize(size);
        text.setTypeface(font);
        fl.addView(text);
    }
    public void setElevation(int l) {
        text.setElevation(l);
    }
    public void remove(FrameLayout layout) {
        layout.removeView(text);
    }
}
class inputText {
    public int n;
    TextView textBar;
    public inputText(int size, int xp, int yp, int w, int h, int co, String text, FrameLayout layout, Context c) {
        textBar = new TextView(c);
        textBar.setText("Click to Enter Text");
//        textBar.setPadding(xp, yp - h, xp + w, yp);
        textBar.setX(xp);
        textBar.setY(yp);
        textBar.setText(text);
        textBar.setTextColor(co);
        textBar.setTextSize(size);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(w, h);
        params.leftMargin = xp;
        params.topMargin = yp;
        textBar.setLayoutParams(params);
        boolean y = false;
        if (text.equalsIgnoreCase("Scouter Name")) {
            n = 1;
            y = true;
        } else if (text.equalsIgnoreCase("Team number")) {
            n = 2;
            y = true;
        } else if (text.equalsIgnoreCase("Match Number")) {
            n = 3;
            y = true;
        }
        if (y) {
            textBar.setOnClickListener(v -> {
                // Create an EditText for input
                EditText input = new EditText(c);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                // Create an AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setTitle("Enter Text")
                        .setView(input)
                        .setPositiveButton("OK", (dialog, which) -> {
                            String userInput = input.getText().toString();
                            if (n == 1) {
                                MainActivity.scouterName = userInput;
                            } else if (n == 2) {
                                MainActivity.teamNumber = userInput;
                            } else if (n == 3) {
                                MainActivity.matchNumber = userInput;
                            }
                            textBar.setText(userInput);
                            Toast.makeText(c, "Text updated", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            });
        }
        layout.addView(textBar);
    }
}













































































